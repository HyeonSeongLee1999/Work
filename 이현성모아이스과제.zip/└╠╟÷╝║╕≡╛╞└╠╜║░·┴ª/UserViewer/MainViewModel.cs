﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Threading;
using System.Windows.Threading;

namespace UserViewer
{
    //UI의 동작을 관리하는 모델
    class MainViewManager : INotifyPropertyChanged
    {
        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region 논 바인딩 데이터들
        //페이지
        MainWindow Page = null;
        //뷰모델
        MainViewModel Model = null;
        //최종저장 리스트
        List<UserData> AllList = new List<UserData>();

        //업데이트 진행시 수정할 유저 전화번호
        ulong updateUserKey = 0;

        //유저 목록 불러오는 인터페이스
        public ILoadUserList<List<UserData>> ILoadUserList = null;
        //유저 목록 저장하는 인터페이스
        public ISaveUserList<bool> ISaveUserList = null;
        #endregion

        #region 커맨드들

        #region UserItemClickCommand
        Command userItemClickCommand = null;
        public Command UserItemClickCommand
        {
            get { return userItemClickCommand; }
            set
            {
                userItemClickCommand = value;
                OnPropertyChanged("UserItemClickCommand");
            }
        }
        #endregion

        #region UserUpdateCommand
        Command userUpdateCommand = null;
        public Command UserUpdateCommand
        {
            get { return userUpdateCommand; }
            set
            {
                userUpdateCommand = value;
                OnPropertyChanged("UserUpdateCommand");
            }
        }
        #endregion

        #region UserDeleteCommand
        Command userDeleteCommand = null;
        public Command UserDeleteCommand
        {
            get { return userDeleteCommand; }
            set
            {
                userDeleteCommand = value;
                OnPropertyChanged("UserDeleteCommand");
            }
        }
        #endregion

        #region UserInsertCommand
        Command userInsertCommand = null;
        public Command UserInsertCommand
        {
            get { return userInsertCommand; }
            set
            {
                userInsertCommand = value;
                OnPropertyChanged("UserInsertCommand");
            }
        }
        #endregion

        #region UserSearchCommand
        Command userSearchCommand = null;
        public Command UserSearchCommand
        {
            get { return userSearchCommand; }
            set
            {
                userSearchCommand = value;
                OnPropertyChanged("UserSearchCommand");
            }
        }
        #endregion

        #region SaveCommand
        Command saveCommand = null;
        public Command SaveCommand
        {
            get { return saveCommand; }
            set
            {
                saveCommand = value;
                OnPropertyChanged("SaveCommand");
            }
        }
        #endregion

        #region AddPopUpCommand
        Command addPopUpCommand = null;
        public Command AddPopUpCommand
        {
            get { return addPopUpCommand; }
            set
            {
                addPopUpCommand = value;
                OnPropertyChanged("AddPopUpCommand");
            }
        }
        #endregion
        #endregion

        //매니저 시작 초기화
        public void BeginWorking(MainViewModel m_Model, MainWindow m_Page)
        {
            #region 비합리 상황에 대한 Exception 유발
            //페이지가 null일 경우 잘못된 사용임으로 Exception을 유발한다.
            if (m_Page == null)
                throw new ArgumentNullException("Page Was Null");
            //모델이 null일 경우 잘못된 사용임으로 Exception을 유발한다.
            if (m_Model == null)
                throw new ArgumentNullException("Model Was Null");
            //ILoadUserList이 null일 경우 잘못된 사용임으로 Exception을 유발한다.
            if (ILoadUserList == null)
                throw new ArgumentNullException("ILoadUserList Was Null");
            if (ISaveUserList == null)
                throw new ArgumentNullException("ISaveUserList Was Null");
            #endregion

            #region 커맨드 초기화
            AddPopUpCommand = new(Execute_AddPopUpCommand);
            UserItemClickCommand = new(Execute_UserItemClickCommand);
            UserUpdateCommand = new(Execute_UserUpdateCommand);
            UserDeleteCommand = new(Execute_UserDeleteCommand);
            UserInsertCommand = new(Execute_UserInsertCommand);
            UserSearchCommand = new(Execute_UserSearchCommand);
            SaveCommand = new(Execute_SaveCommand);
            #endregion

            //모델과 페이지 전달
            this.Page = m_Page;
            this.Model = m_Model;

            //Page의 DataContext를 현 Viewmodel로 맟추어 준다.
            if (m_Page.DataContext != m_Model)
                m_Page.DataContext = m_Model;

            //검색시 엔터키를 누르면 서치한다.
            this.Page.txt_Search.KeyDown += SerchKeyDown;

            LoadAsync(m_Model, m_Page);
        }

        #region SerchKeyDown
        void SerchKeyDown(object sender, KeyEventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (e.Key == Key.Enter)
            {
                Execute_UserSearchCommand(txt.Text);
            }
        }
        #endregion

        //파일이나 DB에 저장된 UserList 불러오기(인터페이스로 파트화)
        public async void LoadAsync(MainViewModel m_Model, MainWindow m_Page)
        {
            //로딩 시작 시점
            await this.Page.Dispatcher.BeginInvoke(async () =>
            {
                //로딩이 표시 시작.
                this.Model.IsPageLoading = true;
                this.Model.PageLoadingMsg = "페이지가 로딩중입니다...";
                await Task.Delay(1000);

                AllList = await ILoadUserList.GetAllUserList();
                ObservableCollection<UserData> loadedList = AllList.ToObservable();

                //바인더용 리스트 삽입
                this.Model.Users = loadedList;

                //로딩 표시 종료
                this.Model.IsPageLoading = false;
                this.Model.PageLoadingMsg = "";
            });
        }

        //Add PopUp띄우기(간단함으로 동기코드 실행)
        #region Execute_AddPopUpCommand
        public async void Execute_AddPopUpCommand(object parameter)
        {
            this.Page.pop_Add.IsOpen = true;
        }
        #endregion

        //데이터 그리드에서 유저를 클릭했을때
        #region Execute_UserItemClickCommand
        public async void Execute_UserItemClickCommand(object parameter)
        {
            await this.Page.Dispatcher.BeginInvoke(async () =>
            {
                #region 불합리 상황 Exception
                if (parameter is not UserData)
                    throw new Exception("Execute_UserItemClickCommand의 파라미터 전달 오류");
                #endregion

                //팝업의 데이터 콘텍스트에 정보 반영
                Model.TmpUpdateData.CloneFromSystem(parameter as UserData);

                //딜레이 삽입(과제에서 요구한 사항 의도 딜레이 1초)
                this.Model.IsPageLoading = true;
                this.Model.PageLoadingMsg = "User 정보가 로딩중입니다...";
                await Task.Delay(1000);
                this.Model.IsPageLoading = false;

                //Popup에 정보를 반영한다.
                updateUserKey = Model.TmpUpdateData.PhonNumber;
                Page.pop_Update.IsOpen = true;
            });
        }
        #endregion

        //유저 정보 수정후 저장을 눌렀을 때
        #region Execute_UserUpdateCommand
        public async void Execute_UserUpdateCommand(object parameter)
        {
            await this.Page.Dispatcher.BeginInvoke(async () =>
            {
                //팝업을 닫는다.
                Page.pop_Update.IsOpen = false;

                //딜레이 삽입(과제에서 요구한 사항 의도 딜레이 1초)
                this.Model.IsPageLoading = true;
                this.Model.PageLoadingMsg = "User 정보를 업데이트 중 입니다....";
                await Task.Delay(1000);

                //업데이트를 위해 열려있는 UserInfo를 찾아낸다.
                UserData findData = AllList.FirstOrDefault((d) => { return d.PhonNumber == updateUserKey; });
                //업데이트할 요소가 없다면 오류 상황임으로 Exception 유발
                if (findData == null)
                    throw new Exception("AllList에서 findData를 찾지 못했습니다.");

                //만일 전화번호가 바뀌었다면 원래 목록에 반영
                //전화번호가 바뀌었다면 다른 목록들 중에 중복이 있는지 확인 후 추기
                if (this.Model.TmpUpdateData.PhonNumber != updateUserKey)
                {
                    UserData SearchDup = this.AllList.FirstOrDefault((d) => { return d.PhonNumber == this.Model.TmpUpdateData.PhonNumber; });
                    //만일 SearchDup이 null이 아니라면 중복되는 전화번호가 있음으로 업데이트를 중단한다.
                    if (SearchDup != null)
                    {
                        MessageBox.Show($"전화번호가 중복되는 유저 정보가 있습니다. 이름: {SearchDup.Name}, 전화번호: {UsefulFuncs.ConvertPhonNumber(SearchDup.PhonNumber)}, 나이: {SearchDup.Age}");
                        //로딩 popup 제거
                        this.Model.IsPageLoading = false;
                        return;
                    }
                }

                //만일 수정이 되지 않았다면 팝업을 원래대로 다시연다.
                if (findData.IsSame(this.Model.TmpUpdateData))
                {
                    MessageBox.Show("유저 정보가 수정되지 않았습니다.");
                    //로딩 popup 제거
                    this.Model.IsPageLoading = false;
                    Page.pop_Update.IsOpen = true;
                    return;
                }

                //저장용 리스트와 화면용 리스트에서 잠시 제거한 후
                this.AllList.Remove(findData);
                this.Model.Users.Remove(findData);
                //정보를 반영하고
                findData.CloneFromSystem(this.Model.TmpUpdateData);
                //정렬삽입한다.
                this.AllList.Insert(findData, UsefulFuncs.UserSortMethod);
                //화면 바인딩용 유저리스트를 초기화 한다
                UsefulFuncs.ResetUsers(this.AllList, this.Model.Users);

                //로딩 popup 제거
                this.Model.IsPageLoading = false;
                MessageBox.Show($"정보가 저장되었습니다. 이름: {findData.Name}, 전화번호: {UsefulFuncs.ConvertPhonNumber(findData.PhonNumber)}, 나이: {findData.Age}");
            });


        }
        #endregion

        //유저 정보 수정후 삭제를 눌렀을 때
        #region Execute_UserDeleteCommand
        public async void Execute_UserDeleteCommand(object parameter)
        {
            await this.Page.Dispatcher.BeginInvoke(async () =>
            {
                //팝업을 닫는다.
                Page.pop_Update.IsOpen = false;

                //딜레이 삽입(과제에서 요구한 사항 의도 딜레이 1초)
                this.Model.IsPageLoading = true;
                this.Model.PageLoadingMsg = "데이터를 삭제중입니다.....";
                await Task.Delay(1000);

                //삭제를 위해 열려있는 UserInfo를 찾아낸다.
                UserData findData = AllList.FirstOrDefault((d) => { return d.PhonNumber == updateUserKey; });
                //삭제할 요소가 없다면 오류 상황임으로 Exception 유발
                if (findData == null)
                    throw new Exception("AllList에서 findData를 찾지 못했습니다.");

                if (findData.IsSupervisor)
                {
                    this.Model.IsPageLoading = false;
                    MessageBox.Show("관리자는 삭제가 불가합니다. 관리자 설정 해지후 삭제해 주세요.");
                    return;
                }

                //저장용 리스트와 화면용 리스트에서 제거
                this.AllList.Remove(findData);
                this.Model.Users.Remove(findData);

                //제거후
                this.Model.IsPageLoading = false;
                MessageBox.Show($"해당 내용이 삭제되었습니다. 이름: {findData.Name}, 전화번호: {UsefulFuncs.ConvertPhonNumber(findData.PhonNumber)}, 나이: {findData.Age}");
            });
        }
        #endregion

        //유저 추가할 때
        #region Execute_UserInsertCommand
        public async void Execute_UserInsertCommand(object parameter)
        {
            await this.Page.Dispatcher.BeginInvoke(async () =>
            {
                //팝업을 닫는다.
                Page.pop_Add.IsOpen = false;

                //딜레이 삽입(과제에서 요구한 사항 의도 딜레이 1초)
                this.Model.IsPageLoading = true;
                this.Model.PageLoadingMsg = "User를 추가하는 중 입니다....";
                await Task.Delay(1000);

                UserData SearchDup = this.AllList.FirstOrDefault((d) => { return d.PhonNumber == this.Model.TmpInsertData.PhonNumber; });
                //만일 SearchDup이 null이 아니라면 중복되는 전화번호가 있음으로 업데이트를 중단한다.
                if (SearchDup != null)
                {
                    MessageBox.Show($"전화번호가 중복되는 유저 정보가 있습니다. 이름: {SearchDup.Name}, 전화번호: {UsefulFuncs.ConvertPhonNumber(SearchDup.PhonNumber)}, 나이: {SearchDup.Age}");
                    //로딩 popup 제거
                    this.Model.IsPageLoading = false;
                    //Add 팝업을 다시연다.
                    Page.pop_Add.IsOpen = true;
                    return;
                }

                //중복되지 않는다면 삽입한다.
                UserData InsertData = new UserData();
                InsertData.CloneFromSystem(this.Model.TmpInsertData);

                //다음 에디트 팝업을 위해 입력한 정보들을 지운다.
                this.Model.TmpInsertData.EmptySelf();

                //정렬삽입한다.
                this.AllList.Insert(InsertData, UsefulFuncs.UserSortMethod);
                //화면 바인딩용 유저리스트를 초기화 한다
                UsefulFuncs.ResetUsers(this.AllList, this.Model.Users);

                //로딩 popup 제거
                this.Model.IsPageLoading = false;
                MessageBox.Show($"정보가 추가되었습니다. 이름: {InsertData.Name}, 전화번호: {UsefulFuncs.ConvertPhonNumber(InsertData.PhonNumber)}, 나이: {InsertData.Age}");
            });


        }
        #endregion

        //유저 검색할 때
        #region Execute_UserSearchCommand
        public async void Execute_UserSearchCommand(object parameter)
        {
            await this.Page.Dispatcher.BeginInvoke(async () =>
            {
                //딜레이 삽입(과제에서 요구한 사항 의도 딜레이 1초)
                this.Model.IsPageLoading = true;
                this.Model.PageLoadingMsg = "User를 검색하는 중 입니다....";
                await Task.Delay(1000);

                UsefulFuncs.ResetUsers(parameter as string, this.AllList, this.Model.Users);

                this.Model.IsPageLoading = false;
                //검색 종료후 포커스를 텍스트박스에 준다.
                this.Page.txt_Search.Focus();
            });


        }
        #endregion

        //저장 커맨드
        #region Execute_SaveCommand
        public async void Execute_SaveCommand(object parameter)
        {
            await this.Page.Dispatcher.BeginInvoke(async () =>
            {
                MessageBoxResult dialogresult = MessageBox.Show("변경내용을 저장하시겠습니까?", "저장", MessageBoxButton.YesNo);
                if (dialogresult != MessageBoxResult.Yes)
                {
                    this.Model.IsPageLoading = false;
                    return;
                }

                //딜레이 삽입(과제에서 요구한 사항 의도 딜레이 1초)
                this.Model.IsPageLoading = true;
                this.Model.PageLoadingMsg = "저장중 입니다....";
                await Task.Delay(1000);

                //인터페이스를 통해 유저 리스트 저장
                bool result = await ISaveUserList.SaveAllUserList(this.AllList);

                this.Model.IsPageLoading = false;

                //저장 결과에 따른 메시지 출력
                string msg = result ? "저장성공" : "저장실패";
                MessageBox.Show(msg);
            });
        }
        #endregion
    }

    //UI의 데이터를 가지고 있는 모델
    class MainViewModel : INotifyPropertyChanged
    {
        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region Manager : 화면 동작기
        MainViewManager manager = null;
        public MainViewManager Manager
        {
            get { return manager; }
            set
            {
                manager = value;
                OnPropertyChanged("Manager");
            }
        }
        #endregion

        #region ObservableCollection<UserData> users : 유저리스트
        ObservableCollection<UserData> users = new ObservableCollection<UserData>();
        public ObservableCollection<UserData> Users
        {
            get { return users; }
            set
            {
                users = value;
                OnPropertyChanged("Users");
            }
        }
        #endregion

        #region bool IsPageEnable : 페이지가 동작 가능한 상태인가
        bool isPageEnable = true;
        public bool IsPageEnable
        {
            get { return isPageEnable; }
            set
            {
                isPageEnable = value;
                OnPropertyChanged("IsPageEnable");
            }
        }
        #endregion

        #region bool IsPageLoading : 페이지가 로딩중인 상태인가
        bool isPageLoading = true;
        public bool IsPageLoading
        {
            get { return isPageLoading; }
            set
            {
                isPageLoading = value;
                OnPropertyChanged("IsPageLoading");
            }
        }
        #endregion
        #region string PageLoadingMsg : 페이지가 로딩메시지
        string pageLoadingMsg = "";
        public string PageLoadingMsg
        {
            get { return pageLoadingMsg; }
            set
            {
                pageLoadingMsg = value;
                OnPropertyChanged("PageLoadingMsg");
            }
        }
        #endregion

        #region UserData TmpUpdateData : 업데이트 팝업창 데이터 콘텍스트
        UserData tmpUpdateData = new UserData();
        public UserData TmpUpdateData
        {
            get { return tmpUpdateData; }
            set
            {
                tmpUpdateData = value;
                OnPropertyChanged("TmpUpdateData");
            }
        }
        #endregion

        #region UserData TmpInsertData : 인서트 팝업창 데이터 콘텍스트
        UserData tmpInsertData = new UserData();
        public UserData TmpInsertData
        {
            get { return tmpInsertData; }
            set
            {
                tmpInsertData = value;
                OnPropertyChanged("TmpInsertData");
            }
        }
        #endregion

        //UI의 페이지와 모델을 동작기에 넘겨준다.
        public void Loaded(MainWindow m_Page)
        {
            //화면 동작기 생성
            Manager = new MainViewManager()
            {
                //유저 불러오는 동작 인터페이스로 전달
                ILoadUserList = new LoadUserListSZ(),
                //유저 저장하는 동작 인터페이스로 전달
                ISaveUserList = new SaveUserListSZ()
            };
            //정보 불러오기 실행
            Manager.BeginWorking(this, m_Page);

        }

    }
}
