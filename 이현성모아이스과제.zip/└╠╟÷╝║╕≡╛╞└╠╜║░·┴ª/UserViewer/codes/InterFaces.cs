﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Threading;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Win32;
using System.Runtime.Serialization;
using System.Xml;

namespace UserViewer
{
    #region 정보 불러오기
    interface ILoadUserList<T>
    {
        public abstract Task<T> GetAllUserList();
    }

    class LoadUserListSZ : ILoadUserList<List<UserData>>
    {
        public async Task<List<UserData>> GetAllUserList()
        {
            return await Task.Run<List<UserData>>(async () =>
            {
                List<UserData> Users = new List<UserData>();

                //저장파일이 있다면 불러오기
                if (File.Exists("UserInfo.txt"))
                {
                    using (FileStream fs = new FileStream("UserInfo.txt", FileMode.Open))
                    {
                        try
                        {
                            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(fs, new XmlDictionaryReaderQuotas());
                            DataContractSerializer ser = new DataContractSerializer(typeof(UserDataSerialize));
                            List<UserData> userdata = (UserDataSerialize)ser.ReadObject(reader);

                            Users = userdata;
                            reader.Close();
                            fs.Close();
                        }
                        catch (Exception ex)
                        {
                        }
                    }
                }

                /*string[] sss = new string[] { "samsung", "moais", "kakao", "devzone", "google", "facebook", "ncsoft", "uber", "apple", "amazone" };
                for (ulong i = 1; i <= 10; i++)
                    Users.Insert(new UserData(sss[i-1], 01098337700ul + i, (ushort)i) { IsSupervisor = true}, UsefulFuncs.UserSortMethod);*/

                return Users;
            });
        }
    }
    #endregion

    #region 정보 저장
    interface ISaveUserList<T>
    {
        public abstract Task<T> SaveAllUserList(List<UserData> savelist);
    }

    class SaveUserListSZ : ISaveUserList<bool>
    {
        //저장 성공시 true 반환
        public async Task<bool> SaveAllUserList(List<UserData> savelist)
        {
            return await Task.Run<bool>(async () =>
            {
                
                //리스트가 없을경우 파일을 삭제한다.
                if (savelist.Count == 0)
                    File.Delete("UserInfo.txt");

                //직렬처리 하며 오류가 나면 실패로 간주한다.
                using (FileStream ws = new FileStream("UserInfo.txt", FileMode.Create, FileAccess.Write ))
                {
                    try
                    {
                        DataContractSerializer ser = new DataContractSerializer(typeof(UserDataSerialize));
                        UserDataSerialize savedata = new UserDataSerialize();

                        foreach(UserData data in savelist)
                        {
                            savedata.Add(data);
                        }

                        ser.WriteObject(ws, savedata);
                        ws.Close();
                    }
                    catch(Exception ex)
                    {
                        return false;
                    }
                }
                return true;
            });
        }
    }
    #endregion
}
