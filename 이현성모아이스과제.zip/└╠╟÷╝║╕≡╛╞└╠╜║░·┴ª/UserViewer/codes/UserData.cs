﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using System.Runtime.Serialization;
using System.Xml;

namespace UserViewer
{
    [CollectionDataContract(Name = "MyTypes", ItemName = "MyType")]
    public class UserDataSerialize : List<UserData>
    {
    }

    //User정보
    [DataContract(Name = "MainData", Namespace = "http://www.contoso.com")]
    public class UserData : INotifyPropertyChanged , IExtensibleDataObject
    {
        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region
        // To implement the IExtensibleDataObject interface, you must also
        // implement the ExtensionData property.
        private ExtensionDataObject extensionDataObjectValue;
        public ExtensionDataObject ExtensionData
        {
            get
            {
                return extensionDataObjectValue;
            }
            set
            {
                extensionDataObjectValue = value;
            }
        }
        #endregion

        public UserData()
        {
            EmptySelf();
        }

        public UserData(string m_Name, ulong m_PhonNumber, ushort m_Age , bool m_IsSupervisor = false)
        {
            this.Name = m_Name;
            this.PhonNumber = m_PhonNumber;
            this.Age = m_Age;
            this.IsSupervisor = m_IsSupervisor;
        }

        //Clone함수
        public void CloneFromSystem(UserData copydata)
        {
            this.Name = copydata.Name;
            this.PhonNumber = copydata.PhonNumber;
            this.Age = copydata.Age;
            this.IsSupervisor = copydata.IsSupervisor;

        }

        public bool IsSame(UserData compareData)
        {
            bool Result = true;

            //이렇게 연산하면 하나라도 false면 결과가 false가 된다.
            Result &= this.Name == compareData.Name;
            Result &= this.PhonNumber == compareData.PhonNumber;
            Result &= this.Age == compareData.Age;
            Result &= this.IsSupervisor == compareData.IsSupervisor;

            return Result;
        }

        public void EmptySelf()
        {
            this.Name = string.Empty;
            this.PhonNumber = 0;
            this.Age = 0;
            this.IsSupervisor = false;
        }

        #region bool IsSupervisor : 중요인물인가
        [DataMember(Name = "IsSupervisor")]
        bool isSupervisor = false;
        public bool IsSupervisor
        {
            get { return isSupervisor; }
            set
            {
                isSupervisor = value;
                OnPropertyChanged("IsSupervisor");
            }
        }
        #endregion

        #region string Name: 이름
        [DataMember(Name = "Name")]
        string name = string.Empty;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged("Name");
            }
        }
        #endregion

        #region ulong PhonNumber: 전화번호
        [DataMember(Name = "PhonNumber")]
        ulong phonNumber = 0l;
        public ulong PhonNumber
        {
            get { return phonNumber; }
            set
            {
                phonNumber = value;
                OnPropertyChanged("PhonNumber");
            }
        }
        #endregion

        #region ushort Age: 나이
        [DataMember(Name = "Age")]
        ushort age = 0;
        public ushort Age
        {
            get { return age; }
            set
            {
                age = value;
                OnPropertyChanged("Age");
            }
        }
        #endregion
    }
}
