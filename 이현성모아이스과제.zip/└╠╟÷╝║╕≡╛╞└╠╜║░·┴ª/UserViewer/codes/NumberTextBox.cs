﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Text.RegularExpressions;

namespace UserViewer
{
    //숫자만 입력 가능한 텍스트 박스
    class NumberTextBox : TextBox
    {
        public NumberTextBox() : base()
        {
            //이벤트 할당
            this.Loaded += NumberTextBox_Loaded;
            this.PreviewMouseWheel += NumberTextBox_PreviewMouseWheel;
        }

        //마우스 휠을 굴려 조작 가능하다
        private void NumberTextBox_PreviewMouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
            //읽기 전용이면 반환한다.
            if (this.IsReadOnly)
                return;

            //현재 텍스트를 ulong로 변환하여 휠이 굴러간 방향에 따라 1을 더하거나 뺀다
            ulong NumVal = 0;
            ulong.TryParse(this.Text as string, out NumVal);
            NumVal = (e.Delta > 0) ? NumVal+1 : NumVal-1;
            this.Text = NumVal.ToString();
        }

        private void NumberTextBox_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.Text == null || this.Text == string.Empty)
            {
                this.Text = "0";
                return;
            }
            this.Text = Regex.Replace(this.Text, @"[^0-9]", "");
        }

        //텍스트를 코드에서 직접 수정하는 경우
        //OnPropertyChanged를 무시해야 하는 경우가 있다
        //그때 무시하라는 flag 값이다.
        protected bool IsTextHandling = false;
        protected override void OnPropertyChanged(System.Windows.DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);

            //TextBox의 Text프로퍼티가 변화하는 순간을 포착한다.
            if (e.Property.Name == "Text")
            {
                if (IsTextHandling)
                {
                    IsTextHandling = false;
                    return;
                }

                ulong NumVal = 0;

                //만약 Text의 속성으로 들어온 문자열이 int로 형변환이 불가하거나 변환이 가능하더라도 MinNumber보다 작으면 Text에 MinNumber를 할당한다.
                IsTextHandling =
                    ((ulong.TryParse(e.NewValue as string, out NumVal) == false) && (e.NewValue as string != string.Empty))
                    || (MinNumber != null && NumVal < MinNumber);
                if (IsTextHandling)
                    this.Text = MinNumber.ToString();
                //만일 MaxNumber보다 큰 수가 Text에 있을경우 
                //MaxNumber * n만큼 늘었을 때 0으로 초기화 되어야 함으로
                //현재 숫자 % (MaxNumber.Value + 1)를 사용한다.
                else if ((MaxNumber != null && NumVal > MaxNumber.Value))
                {
                    IsTextHandling = true;
                    this.Text = (NumVal % (MaxNumber.Value + 1)).ToString();
                }
            }

        }


        //만일 최소숫자나 최대 숫자가 null이 아닌경우 제한이 없다는 것이다.

        //최소 숫자
        public ulong? MinNumber
        {
            get { return (ulong?)GetValue(MinNumberProperty); }
            set { SetValue(MinNumberProperty, value); }
        }

        public static readonly DependencyProperty MinNumberProperty
            = DependencyProperty.Register("MinNumber", typeof(ulong?), typeof(NumberTextBox),
                new FrameworkPropertyMetadata() {DefaultValue=0ul});

        //최대 숫자
        public ulong? MaxNumber
        {
            get { return (ulong?)GetValue(MaxNumberProperty); }
            set { SetValue(MaxNumberProperty, value); }
        }

        public static readonly DependencyProperty MaxNumberProperty
            = DependencyProperty.Register("MaxNumber", typeof(ulong?), typeof(NumberTextBox),
                new FrameworkPropertyMetadata(null));

    }
}
