﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using System.Text.RegularExpressions;

namespace UserViewer
{
    public class PhonNumberConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value is not ulong)
                return Binding.DoNothing;

            ulong LPN = (ulong)value;

            return UsefulFuncs.ConvertPhonNumber(LPN);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is not string)
                return Binding.DoNothing;

            string strNum = string.Empty;

            strNum = Regex.Replace((string)value, @"[^0-9]", "");

            if (strNum == string.Empty)
                return 0ul;

            ulong LPN = 0ul;

            if(ulong.TryParse(strNum, out LPN) == false)
                return Binding.DoNothing;

            return LPN;
        }
    }
}
