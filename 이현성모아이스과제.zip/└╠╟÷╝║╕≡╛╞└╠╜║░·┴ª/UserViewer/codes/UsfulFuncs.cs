﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Text.RegularExpressions;

namespace UserViewer
{
    static class UsefulFuncs
    {
        //ulong형태의 전화번호를 문자열로 변환
        public static string ConvertPhonNumber(ulong LPN)
        {
            return MakePhonNumberStyle("0" + LPN.ToString());
        }

        public static string MakePhonNumberStyle(string strPN)
        {
            if (strPN == null || strPN == "00")
                return string.Empty;

            if (strPN.IndexOf("1") == 1)//지역번호가 010으로 시작하는 경우
            {
                if (strPN.Length >= 3)
                    strPN = strPN.Insert(3, "-");
                if (strPN.Length >= 8)
                    strPN = strPN.Insert(8, "-");
            }
            else if (strPN.IndexOf("2") == 1)//지역번호가 02로 시작하는 경우
            {
                if (strPN.Length >= 2)
                    strPN = strPN.Insert(2, "-");
                if (strPN.Length >= 7)
                    strPN = strPN.Insert(7, "-");
            }
            else//나머지 지역번호의 경우
            {
                if (strPN.Length >= 3)
                    strPN = strPN.Insert(3, "-");
                if (strPN.Length >= 7)
                    strPN = strPN.Insert(7, "-");
            }

            return strPN;
        }

        //List를 ObservableCollection로 바꾸는 확장메서드
        public static ObservableCollection<T> ToObservable<T>(this List<T> list)
        {
            ObservableCollection<T> result = new ObservableCollection<T>();

            if (list == null)
                return null;

            foreach (T item in list)
            {
                result.Add(item);
            }

            return result;
        }

        //List정렬 삽입하는 메서드
        public static void Insert<T>(this List<T> m_list, T m_Data, Func<T,T,bool> SortMthod)
        {
            if (m_list == null)
                return;

            if (m_list.Count == 0)
            {
                m_list.Add(m_Data);
                return;
            }

            for (int i = 0; i < m_list.Count; i++)
            {
                //m_Data 현재 리스트[i] 보다 앞에 있어야 한다면 그제서야 삽입한다
                if (SortMthod(m_list[i], m_Data))
                {
                    m_list.Insert(i, m_Data);
                    return;
                }
            }

            //문제가 있다 string.Compare가 가끔 동작을 잘 못한다...
            //그래서 추가가 되지 못했다면 아쉬운대로 제일 뒤에 붙인다.
            m_list.Add(m_Data);
        }

        //ObservableCollection정렬 삽입하는 메서드
        public static void Insert<T>(this ObservableCollection<T> m_list, T m_Data, Func<T, T, bool> SortMthod)
        {
            if (m_list == null)
                return;

            if (m_list.Count == 0)
            {
                m_list.Add(m_Data);
                return;
            }
             
            for (int i = 0; i < m_list.Count; i++)
            {
                //m_Data 현재 리스트[i] 보다 앞에 있어야 한다면 그제서야 삽입한다
                if (SortMthod(m_list[i], m_Data))
                {
                    m_list.Insert(i, m_Data);
                    return;
                }
            }

            //문제가 있다 string.Compare가 가끔 동작을 잘 못한다...
            //그래서 추가가 되지 못했다면 아쉬운대로 제일 뒤에 붙인다.
            m_list.Add(m_Data);
        }

        //리스트 sort용 메서드
        public static bool UserSortMethod(UserData listData, UserData insertData)
        {
            //관리자 권한이 다르다면 더 놓은 사람이 앞으로 와야한다.
            if(listData.IsSupervisor != insertData.IsSupervisor)
            {
                return listData.IsSupervisor.CompareTo(insertData.IsSupervisor) < 0;
            }
            
            //이름이 사전식으로 봤을 때 더 작은 사람이 앞으로 와야한다.
            if (listData.Name != insertData.Name)
            {
                //어느 문자열의 길이가 더 긴가
                bool MaxLen = (listData.Name.Length > insertData.Name.Length);
                //더 짧은 문자열의 길이 대입
                int NCount = MaxLen ? insertData.Name.Length : listData.Name.Length;
                for(int i = 0; i < NCount; i++)
                {
                    int compareNumBefore = listData.Name.Trim()[i].CompareTo(insertData.Name.Trim()[i]);
                    //먼저 대소문자 구별 비교
                    if (compareNumBefore != 0)
                    {
                        int compareNumAfter = listData.Name.Trim().ToLower()[i].CompareTo(insertData.Name.ToLower()[i]);
                        //대소문자 구별하지 않고 비교해봄
                        if (compareNumAfter == 0)
                        {
                            //만일 대소문자 구별할때는 차이가 있었지만 구별하지 않고는 차이가 없었다면
                            //같은 문자에 대소판별만 다른것이다 그럼으로 대소문자 판별전의 비교로 반환한다.
                            return compareNumBefore > 0;
                        }
                        else
                        {
                            //만일 대소문자 구별할때는 차이가 있고 구별하지 않고도 차이가 있다면
                            //대소문자 판별후의 비교로 반환한다.
                            return compareNumAfter > 0;
                        }
                    }
                }
                //여기까지 왔으면 문자열의 길이로 판별
                return MaxLen;
            }

            //최종적으로는 나이순으로 들어간다
            return listData.Age > insertData.Age;

        }

        //화면용 User리스트를 Manager의 AllList와 맞춘다
        public static void ResetUsers(List<UserData> allList, ObservableCollection<UserData> users)
        {
            //allList에 존재하지 않는게 users에 존재한다면 삭제한다
            foreach (var data in users)
            {
                if (allList.Contains(data) == false)
                {
                    //정렬삽입한다.
                    users.Remove(data);
                }
            }

            //allList에 있는게 users에 없다면 추가한다
            foreach (var data in allList)
            {
                if(users.Contains(data) == false)
                {
                    //정렬삽입한다.
                    users.Insert(data, UsefulFuncs.UserSortMethod);
                }
            }
        }

        //AllList에서 특정 문자열을 검색해 바인딩용 리스트에 업데이트 한다.
        public static void ResetUsers( string SearchStr, List<UserData> allList, ObservableCollection<UserData> users)
        {
            //만약 빈문자열 검색이면 원래대로 되돌린다.
            if(SearchStr == string.Empty || SearchStr == null)
            {
                ResetUsers(allList, users);
                return;
            }

            //바인딩용 데이터 클리어
            int n = users.Count;
            for (int i = 0; i < n; i++)
            {
                users.RemoveAt(0);
            }

            //allList에 있는게 users에 없다면 추가한다
            foreach (var data in allList)
            {
                //입력한 정보가 전화번호일 경우를 대비하여 비교 문자열을 만든다.
                string SearchNumStr = Regex.Replace(SearchStr, @"[^0-9]", "");
                string CurStr = "0"+data.PhonNumber.ToString();
                //이름이나 전화번호에 해당 문자열이 포함되어 있는지 확인 후 되어있으면 추가한다.
                if (data.Name.Trim().ToLower().Contains(SearchStr.Trim().ToLower()) || (CurStr.Contains(SearchNumStr) && SearchNumStr != string.Empty))
                {
                    //정렬삽입한다.(allList가 무조건 정렬되어 있다고 보고 있음으로 그냥 Add로 처리해도 무방하다.)
                    users.Add(data);
                }
            }
        }
    }
}
