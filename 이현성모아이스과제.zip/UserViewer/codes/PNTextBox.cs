﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Text.RegularExpressions;

namespace UserViewer
{
    //숫자만 입력 가능한 텍스트 박스
    class PNTextBox : TextBox
    {
        public PNTextBox() : base()
        {
            //이벤트 할당
            this.Loaded += NumberTextBox_Loaded;
            this.LostFocus+=TextBox_LostFocus;
        }

        //처음 텍스트가 로딩될때 텍스트를 스타일링 한다
        private void NumberTextBox_Loaded(object sender, RoutedEventArgs e)
        {
            //로딩시에 코드에서 강제로 this.Text를 수정함으로 변경 이벤트를 핸들링한다.
            StyleText(this.Text);
        }

        //포커스가 나갈때 텍스트를 스타일링 한다
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            StyleText(this.Text);
        }

        //Text를 전화번호 형태로 변경한다
        void StyleText(string m_text)
        {
            if(m_text == null || m_text == string.Empty)
            {
                this.Text = string.Empty;
                return;
            }
            string result = Regex.Replace(m_text, @"[^0-9]", "");

            result = UsefulFuncs.MakePhonNumberStyle(result);
            this.Text = result;
        }

    }
}
