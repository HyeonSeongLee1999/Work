﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace UserViewer
{
    public class Command : ICommand
    {
        public event EventHandler CanExecuteChanged;

        public Func<object, bool> _CanExecute;
        public Action<object> _Execute;

        public Command() { }

        public Command(Action<object> m_Execute ,Func<object, bool> m_CanExecute = null ) 
        {
            _CanExecute = m_CanExecute;
            _Execute = m_Execute;
        }

        public bool CanExecute(object parameter)
        {
            if (_CanExecute != null)
                return _CanExecute(parameter);

            return true;
        }
        //넘겨받은 메서드 실행
        public void Execute(object parameter)
        {
            if(_Execute != null)
                _Execute(parameter);
        }
    }
}
